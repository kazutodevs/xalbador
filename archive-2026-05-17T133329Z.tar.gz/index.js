const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const { Client, GatewayIntentBits } = require('discord.js');
const fs = require('fs');

const app = express();
const server = http.createServer(app);
const io = new Server(server);

app.use(express.json());
app.use(express.static('public'));

// ========================================================
//              KONFIGURASI BOT DISCORD
// ========================================================
const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMembers,
        GatewayIntentBits.DirectMessages,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent
    ]
});

// Masukkan Token Bot dan ID Discord Anda di bawah ini
const BOT_TOKEN = 'MTUwNTIyNjE4MzcyODY5NzM3NA.GrxyVP.1ISgj4fwOkAo0UeYTzBd23De9Jcqpfa-AhHFe4'; 
const MY_DISCORD_ID = '338221828398907402'; 

client.once('ready', () => {
    console.log(`🤖 Bot Discord Terhubung! Aktif sebagai: ${client.user.tag}`);
});

// ========================================================
//     SISTEM BALAS CHAT DARI DISCORD KE WEBSITE (2 ARAH)
// ========================================================
client.on('messageCreate', async (message) => {
    // Memastikan yang mengetik pesan di DM Bot adalah Anda (Owner), bukan orang lain/bot sendiri
    if (message.author.bot || message.author.id !== MY_DISCORD_ID) return;

    // Mengirimkan ketikan Anda di DM Discord langsung ke layar Live Chat Website
    io.emit('receiveMessage', {
        user: "✨ ADMIN XALBADOR",
        message: message.content
    });
    
    // Memberikan tanda centang hijau di Discord sebagai info bahwa pesan sukses terkirim ke web
    try {
        await message.react('✅');
    } catch (err) {
        console.error("Gagal memberikan react:", err.message);
    }
});

client.login(BOT_TOKEN).catch(err => {
    console.error("❌ Gagal login Bot Discord! Periksa kembali token Anda.", err.message);
});

// ========================================================
//       SIMULASI DATABASE JSON AGAR DATA TIDAK RESET
// ========================================================
const DB_FILE = './usersDB.json';

function loadUsers() {
    try {
        if (!fs.existsSync(DB_FILE)) {
            fs.writeFileSync(DB_FILE, JSON.stringify([], null, 2));
            return [];
        }
        const data = fs.readFileSync(DB_FILE, 'utf8');
        return JSON.parse(data);
    } catch (error) {
        return [];
    }
}

function saveUsers(users) {
    try {
        fs.writeFileSync(DB_FILE, JSON.stringify(users, null, 2));
    } catch (error) {}
}

let usersDB = loadUsers();
const otpStore = {};

// ========================================================
//                    API ENDPOINTS
// ========================================================

// 1. API REGISTER + KIRIM OTP
app.post('/api/auth/register', async (req, res) => {
    const { username, email, password, discordId } = req.body;
    if(!username || !email || !password || !discordId) {
        return res.status(400).json({ error: 'Seluruh form pendaftaran wajib diisi!' });
    }
    
    const generatedOtp = Math.floor(100000 + Math.random() * 900000).toString();
    otpStore[username] = { email, password, discordId, otp: generatedOtp };
    
    try {
        const discordUser = await client.users.fetch(discordId);
        await discordUser.send({
            embeds: [{
                title: "🔐 VERIFIKASI OTP - XALBADOR STORE",
                description: `Halo **${username}**,\nBerikut adalah kode OTP verifikasi pendaftaran akun store Anda:`,
                color: 0xef4444, 
                fields: [
                    { name: "Kode OTP Anda", value: `\`\`\`css\n${generatedOtp}\n\`\`\``, inline: false }
                ],
                footer: { text: "XALBADOR STORE" },
                timestamp: new Date()
            }]
        });
        return res.json({ message: 'Kode OTP berhasil dikirim ke DM Discord Anda!' });
    } catch (error) {
        return res.status(500).json({ error: 'Gagal mengirim OTP! Pastikan ID Discord benar & Anda sudah join server kami.' });
    }
});

// 2. API VERIFIKASI OTP
app.post('/api/auth/verify', (req, res) => {
    const { username, otp } = req.body;
    const tempUserData = otpStore[username];

    if(!tempUserData || tempUserData.otp !== otp) {
        return res.status(422).json({ error: 'Kode OTP salah atau kedaluwarsa!' });
    }

    usersDB = loadUsers();
    usersDB.push({
        username,
        email: tempUserData.email,
        password: tempUserData.password,
        discordId: tempUserData.discordId
    });
    saveUsers(usersDB);

    delete otpStore[username];
    return res.json({ message: 'Registrasi sukses! Akun Anda kini aktif.' });
});

// 3. API LOGIN
app.post('/api/auth/login', (req, res) => {
    const { username, password } = req.body;
    usersDB = loadUsers();
    const user = usersDB.find(u => u.username === username && u.password === password);

    if(!user) {
        return res.status(401).json({ error: 'Username atau password salah!' });
    }
    return res.json({ message: 'Login sukses!', user: { username: user.username, email: user.email } });
});

// 4. API CHECKOUT PRODUCT
app.post('/api/checkout', async (req, res) => {
    const { username, email, discordId, serviceName, ram, disk, price, details } = req.body;
    
    try {
        const owner = await client.users.fetch(MY_DISCORD_ID);
        await owner.send({
            embeds: [{
                title: "🛒 PESANAN BARU MASUK!",
                color: 0x22c55e, 
                fields: [
                    { name: "Layanan", value: `**${serviceName || 'Premium Product'}**`, inline: false },
                    { name: "Spesifikasi", value: `RAM: ${ram || 'N/A'} | Disk: ${disk || 'N/A'}`, inline: true },
                    { name: "Harga", value: `**${price || 'Sesuai Katalog'}**`, inline: true },
                    { name: "Pelanggan", value: `User: ${username} | Email: ${email}`, inline: false }
                ],
                timestamp: new Date()
            }]
        });
        return res.json({ message: `Pesanan berhasil dibuat! Nota telah diteruskan ke Admin.` });
    } catch (error) {
        return res.status(500).json({ error: 'Gagal memproses order ke sistem Discord Admin.' });
    }
});

// ========================================================
//          SOCKET.IO (WEB CHAT -> DISCORD DM)
// ========================================================
io.on('connection', (socket) => {
    socket.on('sendMessage', async (data) => {
        io.emit('receiveMessage', data);

        try {
            const owner = await client.users.fetch(MY_DISCORD_ID);
            await owner.send({
                embeds: [{
                    title: "💬 LIVE CHAT MASUK - CUSTOMER SERVICE",
                    color: 0x2563eb, 
                    fields: [
                        { name: "Pengirim di Web", value: `👤 **${data.user}**`, inline: true },
                        { name: "Isi Pesan", value: `\`\`\`text\n${data.message}\n\`\`\``, inline: false }
                    ],
                    footer: { text: "Balas DM ini langsung untuk membalas ke website." },
                    timestamp: new Date()
                }]
            });
        } catch (err) {
            console.error("❌ Gagal meneruskan chat ke Discord:", err.message);
        }
    });
});

const PORT = 3000;
server.listen(PORT, () => {
    console.log(`🚀 XALBADOR STORE berjalan pada port ${PORT}`);
});